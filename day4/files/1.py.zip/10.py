import shutil

shutil.make_archive('1.py', 'zip')
