fa = open("bojack.txt", "r")

stra = fa.readlines()
print(stra)

fa.close()
