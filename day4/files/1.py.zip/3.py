fa = open("bojack.txt", "r")

stra = fa.readline(7)
print(stra)

stra = fa.readline()
print(stra)

fa.close()
