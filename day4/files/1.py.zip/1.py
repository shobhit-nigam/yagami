fa = open("bojack.txt", "r")

#print(type(fa))

stra = fa.read(7)
print(stra)

fa.close()
