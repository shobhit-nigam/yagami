fa = open("bojack.txt", "r")

stra = fa.read(7)
print(stra)

stra = fa.read(7)
print(stra)

fa.close()
