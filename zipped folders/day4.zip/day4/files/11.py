import shutil

print(shutil.get_archive_formats())
# shutil.unpack_archive
