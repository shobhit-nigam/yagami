listx = {'aa', 'bb', 'cc', 'dd'}
listy = {'ff', 'tt', 'ww', 'rr'}

print(listx - listy)
# error
print(listx + listy)
