def hi():
    print("hello")


def hello():
    print("hello there")


hi()

def hi():
    print("let the force be with you")

hi()

hi = hello

hi()
