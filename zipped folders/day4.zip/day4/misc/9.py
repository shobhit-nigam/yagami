from time import sleep

sleep(5)
print("----")

def sleep():
    print("hello")


sleep()
