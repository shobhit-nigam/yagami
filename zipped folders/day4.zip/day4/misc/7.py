stra = "hello"
strb = "hi"

print(stra+strb)

print(stra+strb*3)
