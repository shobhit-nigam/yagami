import matplotlib.pyplot as plt

lista = [1, 2, 3, 4]
listb = [1, 5, 7, 13]

help(plt.plot)

plt.plot(lista, listb, '--g')
plt.plot(lista, listb, 'ro')

plt.show()
