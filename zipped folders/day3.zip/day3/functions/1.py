def greet():
    print("hello")
    print("good morning")


greet()
