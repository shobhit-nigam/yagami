def greet():
    print("hello")
    print("good morning")

x = greet()

print("x =", x)
print(type(x))
