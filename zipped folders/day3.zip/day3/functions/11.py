def funca(la, lb):
    return la+lb

varx = funca(100, 200)
print("varx =", varx)
