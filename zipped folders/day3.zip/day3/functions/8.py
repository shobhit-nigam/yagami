print("hi", end=', ')
print("hello", end=', ')
print("nice dp")
# blocked
