def funca(la=66, lb=99):
    print("la =", la)
    print("lb =", lb)

funca(11)
