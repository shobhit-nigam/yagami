def funca(la, lb):
    print("la =", la)
    print("lb =", lb)

funca(11, 44)
