def funca(la=66, lb=222, lc=111):
    print("la =", la)
    print("lb =", lb)
    print("lc =", lc)

funca(lb=100)
