def funca(la=66, *args, **kwargs):
    print("la =", la)
    print("args =", args)
    print("kwargs =", kwargs)

funca(100, 200, 300, 400, 500, country='india', area='hind')
