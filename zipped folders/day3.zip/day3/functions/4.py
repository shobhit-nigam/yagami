# error 
def funca(la=66, lb, lc=111):
    print("la =", la)
    print("lb =", lb)
    print("lc =", lc)

funca(100)
