import os

print(os.path.exists('/Users/shobhit/Desktop/qualcomm/day4'))
