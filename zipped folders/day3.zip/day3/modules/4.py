varx = "hello"

print = 10
# error
print(varx)
