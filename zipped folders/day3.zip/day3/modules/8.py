import os

print(os.getcwd())

os.chdir("../../")
print(os.getcwd())

os.mkdir('sample')
