import os

print(os.stat('hello.txt'))
