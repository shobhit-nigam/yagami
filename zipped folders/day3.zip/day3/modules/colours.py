def blue():
    print("cobalt blue")

def red():
    print("cadmium red")

def purple():
    print("purple is a mixture of")
    blue()
    red()
