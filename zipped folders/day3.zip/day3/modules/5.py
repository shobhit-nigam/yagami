varx = "hello"

print = 10


__builtins__.print(varx)



# __builtins__
# __builtin__
