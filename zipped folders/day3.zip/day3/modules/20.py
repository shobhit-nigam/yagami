import datetime

objl = datetime.date(2020, 3, 25)

objd = datetime.date.today()


since = objd - objl
print('since =', since)
