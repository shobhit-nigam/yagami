varx = "hello"

show = print
show(varx)
