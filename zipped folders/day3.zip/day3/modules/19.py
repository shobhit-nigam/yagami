import datetime

objd = datetime.datetime.now()
print(objd)

objd = datetime.date.today()
print(objd)
