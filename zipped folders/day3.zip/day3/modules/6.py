import time

print("hi")
time.sleep(5)
print("hello")
