varx = 30
print(dir())
