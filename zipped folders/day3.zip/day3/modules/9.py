import os
import platform

print(os.name)
print(os.uname())

print(platform.system())
