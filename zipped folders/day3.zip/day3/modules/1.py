#  __builtins__

print("hello world")

print(type(print))
