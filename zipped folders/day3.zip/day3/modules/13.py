import colours

colours.red()
print("------")
colours.purple()
