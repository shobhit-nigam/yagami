listx = ['aa', 'bb', 'cc', 'dd', 'ee', 'ff', 'gg', 'hh']
print("listx =", listx)

del listx[3]
print("listx =", listx)

del listx[1:4]
print("listx =", listx)
