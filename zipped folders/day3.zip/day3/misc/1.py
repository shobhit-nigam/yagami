varx = 30
print("varx =", varx)

del varx
print("varx =", varx)
