varx = None
vary = 30

print("varx =", varx)
print(type(varx))
