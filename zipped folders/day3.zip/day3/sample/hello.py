def greet():
    print("good day")

listd = [10, 30, 40]
