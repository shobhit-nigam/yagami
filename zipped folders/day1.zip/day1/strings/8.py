# functions (methods)

game = "hockey"
print("game =", game)
print("game.upper() =", game.upper())
print("game =", game)
