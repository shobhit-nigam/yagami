
game = "hockey"
print("game = ", game)
print("game[2] = ", game[2])
print("game[-1] = ", game[-1])
print("game[-4] = ", game[-4])

# error
print("game[10] =", game[10])
