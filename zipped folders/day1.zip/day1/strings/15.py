# functions (methods)


game = "women's hockey team"
print(game.replace('hockey', 'golf'))
print(game)
