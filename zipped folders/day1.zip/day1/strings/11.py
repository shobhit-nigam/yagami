# functions (methods)
# immutable

game = "1hockey"
print("game =", game)
print("game.upper() =", game.upper())               # 1HOCKEY
print("game.capitalize() =", game.capitalize())     # 1hockey
print("game =", game)
