place = "india"
country = 'india'

print("type of place =", type(place))
print("type of country =", type(country))
print("type of place[0] =", type(place[0]))
