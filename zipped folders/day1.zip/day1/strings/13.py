# functions (methods)
# immutable

game = "women's hockey team"
print(game.capitalize())
print(game.title())
