# functions (methods)


game = "women's hockey team"
print(game.index('h'))
print(game.index('team'))
print(game.count('e'))
print(game.index('e'))
print(game.rindex('e'))
