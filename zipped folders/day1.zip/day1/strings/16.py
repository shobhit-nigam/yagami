# functions (methods)


game = "women's hockey team"
new_game = game.replace('hockey', 'golf')
print("game =", game)
print("new_game =", new_game)
print("----- ")
game = game.replace('hockey', 'golf')
print("game =", game)
print("new_game =", new_game)
