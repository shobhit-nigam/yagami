# functions (methods)
# immutable

game = "hockey"
print("game =", game)
# error
game[0] = 'H'
print("game =", game)
