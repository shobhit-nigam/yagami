# functions (methods)
# immutable

game = "hockey"
print("game =", game)
print("game.upper() =", game.upper())
print("game =", game)

game = "badminton"
print("game =", game)
print("game.upper() =", game.capitalize())
print("game =", game)
