# functions (methods)
# immutable

game = "1hockey"
print("game =", game)
print("game[2:6].isalpha() =", game.isalpha())
print("game.isalnum() =", game.isalnum())             
