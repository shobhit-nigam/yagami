place = "india"
country = 'india'

stra = 'i love "sienfeld"'
print(stra)

strb = "she does'nt love me"
print(strb)

# error
# area = "hind'
