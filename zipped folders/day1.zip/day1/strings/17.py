# escape sequences

stra = "a  b"
strb = "a\tb"

print("stra =", stra)
print("strb =", strb)

print("len of stra =", len(stra))
print("len of strb =", len(strb))
