# slicing

game = "hockey"
print("game = ", game)
print("length of game =", len(game))
print("game[1:4] = ", game[1:4])
print("game[-5:-2] = ", game[-5:-2])

# no error
print("game[3:10] =", game[3:10])
print("game[10:20] =", game[10:20])
print("length of game[10:20] =", len(game[10:20]))
