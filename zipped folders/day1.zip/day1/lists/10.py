# functions
avengers = ['captain', 'thor', 'black widow', 'hulk', 'groot', 'Star-lord', 'Rocket', 'falcon']

print(avengers)
print("----")
print(avengers.index('hulk'))
print("----")
print(avengers.count('hulk'))
print("----")
avengers.reverse()
print(avengers)
print("----")
avengers.sort()
print(avengers)
#print("----")
# avengers.sort(reverse = True)
