# functions
avengers = ['captain', 'thor', 'black widow', 'hulk', 'groot', 'Star-lord', 'Rocket', 'falcon']

print(avengers)
print("----")
avengers.insert(2, 'hawkeye')
print(avengers)
#print("----")

avengers[avengers.len()-2]
avengers[len(avengers)-2]
