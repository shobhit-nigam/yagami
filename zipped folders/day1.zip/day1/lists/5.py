avengers = ['captain', 'thor', 'black widow', 'hulk']
xmen = ['magneto', 'mystique', 'wolverine']
marvel = [avengers, xmen, 'spiderman']
print(len(marvel))
print(marvel)
xmen.append('jean')
print("-----")
print(marvel)
