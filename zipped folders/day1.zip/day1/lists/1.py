bbt = ['sheldon', 'howard', 'raj', 'amy', 'penny']
print(type(bbt))
print(type(bbt[0]))

num = [12, 45, 89]
