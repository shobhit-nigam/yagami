avengers = ['captain', 'thor', 'black widow', 'hulk']
xmen = ['magneto', 'mystique', 'wolverine']
marvel = [avengers, xmen, 'spiderman']
print("marvel =",marvel)
print("-----")
print("marvel[0] =", marvel[0])
print("-----")
print("marvel[0][2] =", marvel[0][2])
print("-----")
print("marvel[0][2][-1] =", marvel[0][2][-1])
