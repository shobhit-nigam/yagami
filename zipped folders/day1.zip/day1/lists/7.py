avengers = ['captain', 'thor', 'black widow', 'hulk']
xmen = ['magneto', 'mystique', 'wolverine']
gaurdians = ['groot']

avengers = ['wanda', 'black panther', 'fury', 'ant man']
avengers[0] = 'vision'
#error
avengers[0][0] = 'v'
