# functions
avengers = ['captain', 'thor', 'black widow', 'hulk', 'groot', 'star-lord', 'rocket', 'falcon']

print(avengers)
print("----")
avengers.pop(5)
print(avengers)
print("----")
avengers.pop()
print(avengers)
print("----")
avengers.remove('thor')
print(avengers)
print("----")
avengers.clear()
print(avengers)
#print("----")
