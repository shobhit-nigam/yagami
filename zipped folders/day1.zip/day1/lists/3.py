bbt = ['sheldon', 'howard', 'raj', 'amy', 'penny']

num = [12, 45, 89]

print(bbt)
bbt[2] = 'bernadette'
print(bbt)
bbt.append('leonard')
print(bbt)

print(len(bbt))
print(bbt[-1])
