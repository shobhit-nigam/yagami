#int varx = 33;

varx = 33
print("data type of varx = ", type(varx))
vary = 22.45
print("data type of vary = ", type(vary))
vary = "Sindhu"
print("data type of vary = ", type(vary))
