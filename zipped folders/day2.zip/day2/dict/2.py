avengers = {'thor':'hammer', 'captain':'shield', 'ironman':'suit', 'wanda':'power'}

print(avengers)
print("----")
avengers['captain'] = ['shield', 'hammer']
avengers['spiderman'] = 'cob webs'
print(avengers)
