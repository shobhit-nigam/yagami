avengers = {'thor', 'captain', 'ironman', 'wanda'}
avengers = {'thor':'hammer', 'captain':'shield', 'ironman':'suit', 'wanda':'power'}

print(type(avengers))
print(avengers)
print(avengers['ironman'])
