avengers = {'thor':'hammer', 'captain':'shield', 'ironman':'suit', 'wanda':'power'}

print(avengers)
print("----")
print(avengers.values())
print("----")
print(list(avengers.values()))
print("----")
print(list(avengers.items()))
