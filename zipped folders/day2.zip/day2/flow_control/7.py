basket_a = ['apple', 'banana', 'pear', 'apple', 'kiwi', 'banana', 'avocado']
basket_b = {'orange', 'plum', 'grapes', 'apple', 'pear', 'raspberry'}

for i in range(len(basket_a)):     # 0, 1, 2, 3, 4, 5, 6
    print("basket_a[i] =", basket_a[i])
