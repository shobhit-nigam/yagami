avengers = {'thor':'hammer', 'captain':'shield', 'ironman':'suit', 'wanda':'power'}

for k, v in avengers.items():
    print(k, "=", v)
