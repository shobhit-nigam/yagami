avengers = {'thor':'hammer', 'captain':'shield', 'ironman':'suit', 'wanda':'power'}

for x in avengers:
    print("key =", x, "val =", avengers[x])
