vala = 100

if vala>=150:
    print("guten tag")
    # some code
elif vala>100:
    print("salaam")
elif vala>=50:
    print("namaste")
elif vala == 100:
    print("sat sri akaal")
else:
    print("good morning")
print("outside the if-else block")
