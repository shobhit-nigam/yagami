vala = 100

while vala > 96:
    print("vala = ", vala)
    vala = vala-1


print("outside the while loop")
