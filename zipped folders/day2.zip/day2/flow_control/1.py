vala = 100

if vala<150:
    print("guten tag")
    # some code
else:
    print("good morning")
