vala = 33
valb = 33,

valc = 100, "hi", [4, 7, 10]

print(type(vala))
print(type(valb))
print(type(valc))
