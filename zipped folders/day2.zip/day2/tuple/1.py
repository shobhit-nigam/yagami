bbt = ('sheldon', 'penny', 'howard', 'amy', 'bernadette')

print(type(bbt))

# error
bbt[1] = 'leonard'
