vala = 33
valb = 33,

valc = 100, "hi", [4, 7, 10]
vald = (30*40+10)
vale = (100)
valf = (100,)


print(type(vala))
print(type(valb))
print(type(valc))
print(type(vald))
print(type(vale))
print(type(valf))
