# stepping
bbt = ('sheldon', 'penny', 'howard', 'amy', 'bernadette')

print(bbt[::2])
print(bbt[-1][::3])
