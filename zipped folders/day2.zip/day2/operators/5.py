# multiple assignment

x = y = z = 100

x, y, z = 100, "hi", [4, 7, 10]

print(z)

# error

x, y = 100, "hi", [4, 7, 10]
