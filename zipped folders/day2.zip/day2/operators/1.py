# floor division
# power
data = 33
val = 7

print(33/7)
print(33//7)
print(33%7)

print(2*3)
print(2**3)
