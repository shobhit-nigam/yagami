# identity
bbt = ('sheldon', 'penny', 'howard', 'amy', 'bernadette')

print(type(bbt) is list)

print(type('p') is str)

data = True

""
''
