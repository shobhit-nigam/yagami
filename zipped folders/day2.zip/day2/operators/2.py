# chaining
data = 33
val = 7

print(11<33>7)
