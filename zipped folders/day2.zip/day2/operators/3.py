# membership
bbt = ('sheldon', 'penny', 'howard', 'amy', 'bernadette')

print('penny' in bbt)

print('p' in 'sheldon')
