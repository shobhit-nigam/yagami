tupa = (10, 33, 20.5, 6, 80, 67)
seta = {'xx', 'yy', 'ww', 'tt', 'ee', 'uu'}
lista = ['hi', 23.56, {6, 8, 9}, [10, 20], 'hello']
stra = "Elon Musk"

print(sum(tupa))
print(max(tupa))
print(min(seta))
print(max(stra))
