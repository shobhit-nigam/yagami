varx = 356
vary = "542"

varz = int(vary)

print(type(vary))

print(type(varz))
