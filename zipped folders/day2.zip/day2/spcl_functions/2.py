varx = 356
vary = "542"

varz = list(vary)

print(type(vary))

print(type(varz))

print(varz)
