# input always a string
varx = input("enter a value:\n")
print("varx =", varx)
print(type(varx))
