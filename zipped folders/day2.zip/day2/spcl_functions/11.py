# input always a string
# eval will evaluate
varx = eval(input("enter a value:\n"))

print("varx =", varx)
print(type(varx))
