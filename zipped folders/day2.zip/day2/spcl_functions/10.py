print(eval("2*3+10"))
varx = 33
print(eval("varx+10"))

# input always a string
# varx = eval(input("enter a value:\n"))
# error if a non numeric string is entered

# print("varx =", varx)
# print(type(varx))
