# input always a string
varx = int(input("enter a value:\n"))
# error if a non numeric string is entered

print("varx =", varx)
print(type(varx))
