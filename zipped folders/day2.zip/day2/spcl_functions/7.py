varx = input()
print("varx =", varx)
