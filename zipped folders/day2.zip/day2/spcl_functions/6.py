varx = 542.67
vary = "542.67"


varz = int(varx)

print(type(varz))

# error
varz = int(vary)

print(type(varz))
